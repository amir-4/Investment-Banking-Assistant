"""
Tools for financial_analyst_agent.

Data tools call the free, official SEC EDGAR XBRL API (data.sec.gov) —
no API key required, but a compliant User-Agent header and rate-limit
discipline are required per SEC guidance.
Docs: https://www.sec.gov/edgar/sec-api-documentation

Calculation tools implement the formulas in
knowledge/valuation_methodology.md and knowledge/financial_ratios_reference.md
exactly — do not change a formula here without updating that file too.
"""

import requests
from ibm_watsonx_orchestrate.agent_builder.tools import tool

SEC_BASE = "https://data.sec.gov"
# SEC requires a descriptive User-Agent identifying the requester.
HEADERS = {"User-Agent": "financial_analyst_agent contact@yourfirm.com"}


@tool
def get_company_cik(ticker: str) -> dict:
    """
    Look up a company's SEC CIK number from its stock ticker.

    Args:
        ticker: Stock ticker symbol, e.g. "AAPL".

    Returns:
        dict with cik (10-digit, zero-padded string) and company title,
        or an error message if the ticker is not found.
    """
    resp = requests.get(
        "https://www.sec.gov/files/company_tickers.json",
        headers=HEADERS, timeout=15,
    )
    resp.raise_for_status()
    data = resp.json()
    ticker_upper = ticker.upper()
    for entry in data.values():
        if entry["ticker"] == ticker_upper:
            return {
                "cik": str(entry["cik_str"]).zfill(10),
                "title": entry["title"],
            }
    return {"error": f"No CIK found for ticker '{ticker}'"}


@tool
def get_company_facts(cik: str) -> dict:
    """
    Retrieve every XBRL-tagged financial fact ever reported by a company.

    Args:
        cik: 10-digit zero-padded SEC CIK number (use get_company_cik first).

    Returns:
        Full companyfacts JSON payload from SEC EDGAR.
    """
    url = f"{SEC_BASE}/api/xbrl/companyfacts/CIK{cik}.json"
    resp = requests.get(url, headers=HEADERS, timeout=15)
    resp.raise_for_status()
    return resp.json()


@tool
def get_company_concept(cik: str, tag: str, taxonomy: str = "us-gaap") -> dict:
    """
    Retrieve the full historical series for one financial line item.

    Args:
        cik: 10-digit zero-padded SEC CIK number.
        tag: XBRL tag, e.g. "Revenues", "NetIncomeLoss", "Assets",
             "StockholdersEquity", "Liabilities". Not every company uses
             the same tag for the same concept — if this returns no
             data, check get_company_facts for the tag actually used.
        taxonomy: XBRL taxonomy, default "us-gaap".

    Returns:
        JSON payload with the tag's full reporting history across filings.
    """
    url = f"{SEC_BASE}/api/xbrl/companyconcept/CIK{cik}/{taxonomy}/{tag}.json"
    resp = requests.get(url, headers=HEADERS, timeout=15)
    resp.raise_for_status()
    return resp.json()


@tool
def calculate_financial_ratios(
    current_assets: float, current_liabilities: float, inventory: float,
    cash: float, total_debt: float, shareholders_equity: float,
    total_assets: float, revenue: float, net_income: float,
    ebit: float, interest_expense: float,
) -> dict:
    """
    Calculate the standard liquidity, profitability, and leverage ratios
    defined in knowledge/financial_ratios_reference.md, from figures
    already pulled from a company's filings.

    All arguments are the underlying financial statement figures for a
    single fiscal period, in the same currency units.

    Returns:
        dict of computed ratios for that period.
    """
    return {
        "current_ratio": current_assets / current_liabilities,
        "quick_ratio": (current_assets - inventory) / current_liabilities,
        "cash_ratio": cash / current_liabilities,
        "net_margin": net_income / revenue,
        "operating_margin": ebit / revenue,
        "roa": net_income / total_assets,
        "roe": net_income / shareholders_equity,
        "debt_to_equity": total_debt / shareholders_equity,
        "interest_coverage": ebit / interest_expense if interest_expense else None,
    }


@tool
def calculate_wacc(
    market_value_equity: float, market_value_debt: float,
    cost_of_equity: float, pre_tax_cost_of_debt: float,
    tax_rate: float, market_value_preferred: float = 0.0,
    cost_of_preferred: float = 0.0,
) -> dict:
    """
    Calculate WACC per the standard formula in
    knowledge/valuation_methodology.md section 3.

    Args:
        market_value_equity: Market value of common equity (E).
        market_value_debt: Market value of total debt (D).
        cost_of_equity: Re, as a decimal (e.g. 0.10 for 10%).
        pre_tax_cost_of_debt: Rd before tax, as a decimal.
        tax_rate: Effective tax rate, as a decimal.
        market_value_preferred: Market value of preferred stock (P), default 0.
        cost_of_preferred: Rp, as a decimal, default 0.

    Returns:
        dict with the WACC and the weight of each capital component, so
        the analyst can see the inputs behind the number, not just the
        result.
    """
    total = market_value_equity + market_value_debt + market_value_preferred
    we = market_value_equity / total
    wd = market_value_debt / total
    wp = market_value_preferred / total
    wacc = (
        we * cost_of_equity
        + wd * pre_tax_cost_of_debt * (1 - tax_rate)
        + wp * cost_of_preferred
    )
    return {
        "wacc": wacc,
        "weight_equity": we,
        "weight_debt": wd,
        "weight_preferred": wp,
    }


@tool
def calculate_dcf(
    projected_fcff: list[float], wacc: float, terminal_growth_rate: float,
    net_debt: float,
) -> dict:
    """
    Calculate implied firm and equity value via DCF, per
    knowledge/valuation_methodology.md section 2.

    Args:
        projected_fcff: Projected free cash flow to the firm for each
            future period (e.g. 5 values for a 5-year projection). Must
            be supplied by the analyst/agent from a built model — this
            tool does not generate projections itself.
        wacc: Discount rate as a decimal (see calculate_wacc).
        terminal_growth_rate: Long-run perpetuity growth rate (g), as a
            decimal. Should be flagged to the user if it looks unusually
            high relative to typical long-run economic growth.
        net_debt: Market value of total debt minus cash and equivalents,
            used to bridge from firm value to equity value.

    Returns:
        dict with discounted cash flows, terminal value (shown
        separately, per methodology notes), firm value, and equity value.
    """
    pv_stage = sum(
        cf / (1 + wacc) ** (t + 1) for t, cf in enumerate(projected_fcff)
    )
    n = len(projected_fcff)
    terminal_fcff = projected_fcff[-1] * (1 + terminal_growth_rate)
    terminal_value = terminal_fcff / (wacc - terminal_growth_rate)
    pv_terminal_value = terminal_value / (1 + wacc) ** n

    firm_value = pv_stage + pv_terminal_value
    equity_value = firm_value - net_debt

    return {
        "pv_of_projection_period_cash_flows": pv_stage,
        "terminal_value_undiscounted": terminal_value,
        "pv_of_terminal_value": pv_terminal_value,
        "terminal_value_pct_of_firm_value": pv_terminal_value / firm_value,
        "firm_value": firm_value,
        "equity_value": equity_value,
    }


@tool
def calculate_comparable_multiples(
    target_metric: dict, peer_multiples: dict[str, list[float]],
) -> dict:
    """
    Derive an implied valuation range for the target company by applying
    peer trading multiples, per knowledge/valuation_methodology.md section 4.

    Args:
        target_metric: The target company's own metrics to which
            multiples will be applied, e.g. {"ebitda": 500_000_000,
            "revenue": 2_000_000_000}.
        peer_multiples: For each multiple type (e.g. "ev_ebitda",
            "ev_revenue"), a list of the peer set's individual multiple
            values (not pre-averaged), so the agent can report both
            median and mean for the analyst to compare.

    Returns:
        dict of implied values per multiple type, using both the peer
        median and mean, so the range — not a single point — is visible.
    """
    import statistics

    results = {}
    metric_map = {"ev_ebitda": "ebitda", "ev_revenue": "revenue"}
    for multiple_name, values in peer_multiples.items():
        metric_key = metric_map.get(multiple_name)
        if metric_key is None or metric_key not in target_metric:
            continue
        median_mult = statistics.median(values)
        mean_mult = statistics.mean(values)
        base = target_metric[metric_key]
        results[multiple_name] = {
            "peer_median_multiple": median_mult,
            "peer_mean_multiple": mean_mult,
            "implied_value_at_median": base * median_mult,
            "implied_value_at_mean": base * mean_mult,
        }
    return results
